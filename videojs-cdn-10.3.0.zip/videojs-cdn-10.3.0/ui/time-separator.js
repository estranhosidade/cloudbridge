/*! Video.js | https://videojs.org/help */
import{t as e}from"../ui-element-tYNJ8-5H.js";import{t}from"../safe-define-DXxmf7BV.js";var n=class extends e{static{this.tagName=`media-time-separator`}connectedCallback(){super.connectedCallback(),this.setAttribute(`aria-hidden`,`true`),this.textContent?.trim()||(this.textContent=`/`)}};t(n);
