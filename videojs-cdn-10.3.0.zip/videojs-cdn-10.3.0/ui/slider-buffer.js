/*! Video.js | https://videojs.org/help */
import{t as e}from"../context-0Uf4tShw.js";import{t}from"../safe-define-DXxmf7BV.js";import{t as n}from"../context-part-element-CU7ViMc2.js";import{t as r}from"../context-D_k9hQ7P.js";var i=class extends n{constructor(...t){super(...t),this.consumer=new e(this,{context:r,subscribe:!0})}static{this.tagName=`media-slider-buffer`}};t(i);
