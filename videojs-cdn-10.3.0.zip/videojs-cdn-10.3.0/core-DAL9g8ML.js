import{n as e}from"./data-Y2i_0KhY.js";var t=class extends e{constructor(){super(`alertdialog`)}};export{t};
