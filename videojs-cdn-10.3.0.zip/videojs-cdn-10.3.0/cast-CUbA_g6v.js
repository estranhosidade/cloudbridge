const e=`cast.`,t={key:`${e}start`,text:`Start casting`},n={key:`${e}stop`,text:`Stop casting`},r={key:`${e}connecting`,text:`Connecting`};export{t as n,n as r,r as t};
