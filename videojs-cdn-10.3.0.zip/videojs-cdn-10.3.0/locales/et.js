/*! Video.js | https://videojs.org/help */
import{t as e}from"../et-Ddz8iUei.js";import{registerI18n as t}from"../i18n.js";t(`et`,e);
