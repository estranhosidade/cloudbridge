/*! Video.js | https://videojs.org/help */
import{t as e}from"../hr-BB0OacCV.js";import{registerI18n as t}from"../i18n.js";t(`hr`,e);
