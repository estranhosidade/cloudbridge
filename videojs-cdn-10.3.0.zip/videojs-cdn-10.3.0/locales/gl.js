/*! Video.js | https://videojs.org/help */
import{t as e}from"../gl-B-s4VMTy.js";import{registerI18n as t}from"../i18n.js";t(`gl`,e);
