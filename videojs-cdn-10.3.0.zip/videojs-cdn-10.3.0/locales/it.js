/*! Video.js | https://videojs.org/help */
import{t as e}from"../it-CJ_aWfLO.js";import{registerI18n as t}from"../i18n.js";t(`it`,e);
