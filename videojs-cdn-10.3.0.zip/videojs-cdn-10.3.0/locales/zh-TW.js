/*! Video.js | https://videojs.org/help */
import{t as e}from"../zh-TW-tpkP9kH2.js";import{registerI18n as t}from"../i18n.js";t(`zh-TW`,e);
