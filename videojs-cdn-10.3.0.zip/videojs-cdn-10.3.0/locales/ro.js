/*! Video.js | https://videojs.org/help */
import{t as e}from"../ro-BeuVB3XC.js";import{registerI18n as t}from"../i18n.js";t(`ro`,e);
