/*! Video.js | https://videojs.org/help */
import{t as e}from"../fr-BN632pmN.js";import{registerI18n as t}from"../i18n.js";t(`fr`,e);
