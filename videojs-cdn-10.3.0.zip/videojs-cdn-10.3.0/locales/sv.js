/*! Video.js | https://videojs.org/help */
import{t as e}from"../sv-CgvN2VmN.js";import{registerI18n as t}from"../i18n.js";t(`sv`,e);
