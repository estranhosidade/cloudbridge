function e(e){try{e()}catch{}}export{e as t};
