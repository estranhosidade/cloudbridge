const e=`<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" aria-hidden="true" viewBox="0 0 18 18"><path stroke="currentColor" d="m3.5 9.5 4 4 7-8"/></svg>`;export{e as t};
