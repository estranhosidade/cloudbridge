function e(e,t=1){let n=Math.round(e.width*t),r=Math.round(e.height*t);return Number.isFinite(n)&&Number.isFinite(r)&&n>0&&r>0?{width:n,height:r}:void 0}export{e as t};
