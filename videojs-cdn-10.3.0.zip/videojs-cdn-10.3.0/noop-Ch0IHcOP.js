function e(...e){}export{e as t};
