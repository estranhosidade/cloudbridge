function e(){return`${Date.now()}-${Math.floor(Math.random()*1e6)}`}export{e as t};
